#define MSG_BLK_LEN 16
#define AD_BLK_LEN_ODD 16
#define AD_BLK_LEN_EVN 16

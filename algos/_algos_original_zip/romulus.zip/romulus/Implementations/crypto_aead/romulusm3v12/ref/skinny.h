extern void skinny_128_256_enc (unsigned char* input, const unsigned char* userkey);

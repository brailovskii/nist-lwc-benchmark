#ifndef API_H
#define API_H

#define CRYPTO_KEYBYTES		16
#define CRYPTO_NSECBYTES	0
#define CRYPTO_NPUBBYTES	12
#define CRYPTO_ABYTES		8
#define CRYPTO_NOOVERLAP	1

#endif

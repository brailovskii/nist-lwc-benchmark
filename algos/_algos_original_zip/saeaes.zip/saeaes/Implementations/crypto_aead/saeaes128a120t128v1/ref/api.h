#define CRYPTO_KEYBYTES  16 // { 16, 24, 32 }
#define CRYPTO_NSECBYTES 0
#define CRYPTO_NPUBBYTES 15
#define CRYPTO_ABYTES    16 // { 8, 16 }
#define CRYPTO_NOOVERLAP 1

//#define saeaes128a64t64v1
//#define saeaes128a64t128v1
//#define saeaes128a120t64v1
#define saeaes128a120t128v1

//#define saeaes192a64t64v1
//#define saeaes192a64t128v1
//#define saeaes192a120t128v1

//#define saeaes256a64t64v1
//#define saeaes256a64t128v1
//#define saeaes256a120t128v1


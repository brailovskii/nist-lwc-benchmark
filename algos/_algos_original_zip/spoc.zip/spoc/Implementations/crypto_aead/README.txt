spoc64sliscplight192128v1: This instance uses the core permutation sliscp192 and has the rate 64 bits and key size 128. 

spoc128sliscplight256128v1: This instance uses the core permutation sliscp256 and has the rate 128 bits and key size 128. 
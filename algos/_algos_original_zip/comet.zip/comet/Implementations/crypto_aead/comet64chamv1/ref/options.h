//Message-Blocksize in bits
#define BLOCKSIZE 64
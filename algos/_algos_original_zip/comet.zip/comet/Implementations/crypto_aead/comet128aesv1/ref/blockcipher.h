
typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long long ull;

void blockcipher_encrypt(u8 *ct, const u8 *pt, const u8 *key);
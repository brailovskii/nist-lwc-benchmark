//Message-Blocksize in bits
#define BLOCKSIZE 128